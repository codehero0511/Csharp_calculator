﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C練習
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            isOperatorPressed = false; // 初始化为运算符未按下
        }
        private double first; // 第一组数字
        private double second; // 第二组数字
        private string mathematical; // 运算符
        private bool isOperatorPressed; // 运算符是否已按下的标志变量


        private void buttonNumber_Click(object sender, EventArgs e)
        {
            Button buttonNumber = sender as Button;

            if (textBox1.Text == "0" || isOperatorPressed )
            {
                textBox1.Text = buttonNumber.Text;
                isOperatorPressed = false;
            }   
            else
            {
                textBox1.Text += buttonNumber.Text;
            }
           
        }

        private void buttonMathematical_Click(object sender, EventArgs e)
        {
            //運算符號第一次按下時
            if (isOperatorPressed == false)
            {
                second = 0;
                Button button = (Button)sender;
                // If textBox1 is empty, set first to 0
                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    first = 0;
                }
                else
                {
                    first = double.Parse(textBox1.Text);
                }
                //first = double.Parse(textBox1.Text);
                mathematical = button.Text;
                textBox1.Text = mathematical;
                isOperatorPressed = true;
            }
            //第二次按下時
            else
            {
                double result = CalculateResult();
                textBox1.Text = result.ToString();
            }
        }

        private void Enter_Click(object sender, EventArgs e)
        {          
            if(second != 0)
            {              
                double result = CalculateResult();
                textBox1.Text = result.ToString();
                first = result;
            }
            //第一次按下輸出
            else
            {
                second = double.Parse(textBox1.Text);
                double result = CalculateResult();
                textBox1.Text = result.ToString();
                first = result;
            }
           
        }
        private double CalculateResult()
        {
            double result = 0;
            switch (mathematical)
            {
                case "+":
                    result = first + second;
                    break;
                case "-":
                    result = first - second;
                    break;
                case "*":
                    result = first * second;
                    break;
                case "/":
                    result = first / second;
                    break;
            }
            //first = 0;
            //second = 0;
            return result;
        }
        private void clear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            first = 0;
            second = 0;
            isOperatorPressed = false;
        }
    }
}
